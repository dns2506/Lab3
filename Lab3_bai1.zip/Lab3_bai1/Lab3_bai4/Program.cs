﻿using System;

namespace Lab3_bai4
{
    // Khai báo Interface kiểm tra tính hợp lệ của dữ liệu
    public interface IValidatable
    {
        bool IsValid(out string message);
    }

    // Khai báo Interface định dạng chuỗi in ra màn hình
    public interface IPrintable
    {
        string ToDisplayText();
    }

    // Lớp SinhVien thực thi đồng thời cả hai Interface
    public class SinhVien : IValidatable, IPrintable
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public double DiemTB { get; set; }

        // Cài đặt logic kiểm tra hợp đồng IValidatable
        public bool IsValid(out string message)
        {
            if (string.IsNullOrWhiteSpace(MaSV))
            {
                message = "Thiếu mã sinh viên!";
                return false;
            }
            if (DiemTB < 0 || DiemTB > 10)
            {
                message = "Điểm trung bình không hợp lệ (phải từ 0 đến 10)!";
                return false;
            }
            message = "";
            return true;
        }

        // Cài đặt logic định dạng hiển thị của IPrintable
        public string ToDisplayText()
        {
            return $"[SV] Mã: {MaSV} - Họ tên: {HoTen} - ĐTB: {DiemTB}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập tiếng Việt cho Console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== DEMO BÀI 4: INTERFACE KIỂM TRA VÀ IN DỮ LIỆU ===");

            // Kiểm thử với sinh viên hợp lệ
            SinhVien sv1 = new SinhVien { MaSV = "SV001", HoTen = "Đỗ Ngọc Sơn", DiemTB = 8.5 };
            if (sv1.IsValid(out string msg1))
            {
                Console.WriteLine("=> Sinh viên 1 hợp lệ:");
                Console.WriteLine(sv1.ToDisplayText());
            }
            else
            {
                Console.WriteLine("=> Lỗi: " + msg1);
            }

            Console.WriteLine();

            // Kiểm thử với sinh viên lỗi điểm số
            SinhVien sv2 = new SinhVien { MaSV = "SV002", HoTen = "Trần Văn Nam", DiemTB = 11.0 };
            if (sv2.IsValid(out string msg2))
            {
                Console.WriteLine("=> Sinh viên 2 hợp lệ:");
                Console.WriteLine(sv2.ToDisplayText());
            }
            else
            {
                Console.WriteLine("=> Lỗi sinh viên 2: " + msg2);
            }

            Console.ReadKey();
        }
    }
}