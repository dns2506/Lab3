﻿using System;

namespace Lab3_bai2
{
    // Lớp cơ sở Nguoi chứa phương thức ảo (virtual) MoTa()
    public class Nguoi
    {
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }

        public Nguoi(string hoTen, DateTime ngaySinh)
        {
            HoTen = hoTen;
            NgaySinh = NgaySinh;
        }

        // Phương thức virtual cho phép lớp con ghi đè
        public virtual string MoTa()
        {
            return HoTen + " - " + NgaySinh.ToString("dd/MM/yyyy");
        }
    }

    // Lớp SinhVien kế thừa Nguoi và ghi đè (override) phương thức MoTa()
    public class SinhVien : Nguoi
    {
        public string MaSV { get; set; }
        public double DiemTB { get; set; }

        public SinhVien(string ma, string ten, DateTime ngaySinh, double diem)
            : base(ten, ngaySinh)
        {
            MaSV = ma;
            DiemTB = diem;
        }

        // Ghi đè phương thức MoTa() bằng từ khóa override, tận dụng base.MoTa()
        public override string MoTa()
        {
            return base.MoTa() + " - " + MaSV + " - " + DiemTB.ToString("N2");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập hiển thị tiếng Việt có dấu trong Console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Khởi tạo một đối tượng SinhVien
            SinhVien sv = new SinhVien("SV001", "Đỗ Ngọc Sơn", new DateTime(2006, 6, 25), 8.5);

            // Gọi phương thức MoTa() đã được ghi đè
            Console.WriteLine("=== KẾT QUẢ GHI ĐÈ PHƯƠNG THỨC MÔ TẢ ===");
            Console.WriteLine(sv.MoTa());

            Console.ReadKey();
        }
    }
}