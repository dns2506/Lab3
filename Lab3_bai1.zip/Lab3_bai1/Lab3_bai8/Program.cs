﻿using System;
using System.Collections.Generic;

namespace Lab3_bai8
{
    // Lớp trừu tượng TaiLieu chứa thông tin chung và phương thức trừu tượng HienThiThongTin()
    public abstract class TaiLieu
    {
        public string MaTaiLieu { get; set; }
        public string TenTaiLieu { get; set; }
        public abstract void HienThiThongTin();
    }

    // Lớp Sach kế thừa TaiLieu
    public class Sach : TaiLieu
    {
        public string TacGia { get; set; }
        public int SoTrang { get; set; }

        public override void HienThiThongTin()
        {
            Console.WriteLine($"[Sách] Mã: {MaTaiLieu} | Tên: {TenTaiLieu} | Tác giả: {TacGia} | Số trang: {SoTrang}");
        }
    }

    // Lớp TapChi kế thừa TaiLieu
    public class TapChi : TaiLieu
    {
        public int SoPhatHanh { get; set; }
        public int ThangPhatHanh { get; set; }

        public override void HienThiThongTin()
        {
            Console.WriteLine($"[Tạp chí] Mã: {MaTaiLieu} | Tên: {TenTaiLieu} | Số PH: {SoPhatHanh} | Tháng: {ThangPhatHanh}");
        }
    }

    // Lớp LuanVan kế thừa TaiLieu
    public class LuanVan : TaiLieu
    {
        public string NguoiBaoVe { get; set; }
        public string ChuyenNganh { get; set; }

        public override void HienThiThongTin()
        {
            Console.WriteLine($"[Luận văn] Mã: {MaTaiLieu} | Tên: {TenTaiLieu} | Tác giả: {NguoiBaoVe} | Ngành: {ChuyenNganh}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập tiếng Việt cho Console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== DEMO BÀI 8: QUẢN LÝ TÀI LIỆU THƯ VIỆN ===");

            // Sử dụng danh sách đa hình lưu trữ các loại tài liệu khác nhau
            List<TaiLieu> dsTaiLieu = new List<TaiLieu>
            {
                new Sach { MaTaiLieu = "S01", TenTaiLieu = "Lập trình C# Nâng cao", TacGia = "Microsoft Press", SoTrang = 350 },
                new TapChi { MaTaiLieu = "TC05", TenTaiLieu = "Khoa học Công nghệ số", SoPhatHanh = 12, ThangPhatHanh = 5 },
                new LuanVan { MaTaiLieu = "LV99", TenTaiLieu = "Ứng dụng AI trong quản lý", NguoiBaoVe = "Đỗ Ngọc Sơn", ChuyenNganh = "Công nghệ Thông tin" }
            };

            Console.WriteLine("\nDanh sách tài liệu trong thư viện:\n");
            foreach (var tl in dsTaiLieu)
            {
                // Gọi phương thức đa hình hiển thị thông tin tương ứng theo từng lớp con
                tl.HienThiThongTin();
            }

            // Ví dụ tìm kiếm tài liệu là Sách
            Console.WriteLine("\n--- Tìm kiếm các đầu sách có trong thư viện ---");
            foreach (var tl in dsTaiLieu)
            {
                if (tl is Sach sach)
                {
                    Console.WriteLine($"- Tìm thấy sách của tác giả {sach.TacGia}: {sach.TenTaiLieu}");
                }
            }

            Console.ReadKey();
        }
    }
}