﻿using System;
using System.Collections.Generic;

namespace Lab3_bai5
{
    // Lớp trừu tượng gốc (tái sử dụng từ cấu trúc Bài 3)
    public abstract class NguoiHoc
    {
        public string HoTen { get; set; }
        public int SoTinChi { get; set; }
        public abstract decimal TinhHocPhi();
    }

    public class SinhVienChinhQuy : NguoiHoc
    {
        public override decimal TinhHocPhi()
        {
            return SoTinChi * 450000m;
        }
    }

    public class SinhVienLienThong : NguoiHoc
    {
        public override decimal TinhHocPhi()
        {
            return SoTinChi * 520000m;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập hiển thị tiếng Việt có dấu trong Console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== DEMO BÀI 5: DANH SÁCH ĐA HÌNH TÍNH HỌC PHÍ ===");

            // Tạo danh sách đa hình chứa nhiều kiểu sinh viên khác nhau thông qua tham chiếu lớp cha NguoiHoc
            List<NguoiHoc> ds = new List<NguoiHoc>();
            ds.Add(new SinhVienChinhQuy { HoTen = "An", SoTinChi = 18 });
            ds.Add(new SinhVienLienThong { HoTen = "Bình", SoTinChi = 15 });

            decimal tong = 0;
            foreach (NguoiHoc item in ds)
            {
                // Tính đa hình: Tự động gọi đúng phương thức TinhHocPhi() của từng lớp con tương ứng
                decimal hocPhi = item.TinhHocPhi();
                tong += hocPhi;
                Console.WriteLine("{0}: {1:N0} VNĐ", item.HoTen, hocPhi);
            }

            Console.WriteLine("----------------------------------------");
            Console.WriteLine("Tổng học phí: {0:N0} VNĐ", tong);

            Console.ReadKey();
        }
    }
}