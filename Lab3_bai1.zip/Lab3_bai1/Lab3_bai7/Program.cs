﻿using System;
using System.Collections.Generic;

namespace Lab3_bai7
{
    // Khai báo Interface IMove định nghĩa hợp đồng di chuyển và tính chi phí
    public interface IMove
    {
        void DiChuyen();
        double TinhChiPhi(double quangDuongKm);
    }

    // Lớp XeMay thực thi interface IMove
    public class XeMay : IMove
    {
        public void DiChuyen()
        {
            Console.WriteLine("Xe máy chạy bằng xăng trên đường bộ (Tốc độ trung bình ~ 60 km/h).");
        }

        public double TinhChiPhi(double quangDuongKm)
        {
            // Giả định: 40 km tốn 1 lít xăng, giá xăng 20,000 VNĐ/lít
            return (quangDuongKm / 40.0) * 20000;
        }
    }

    // Lớp OTo thực thi interface IMove
    public class OTo : IMove
    {
        public void DiChuyen()
        {
            Console.WriteLine("Ô tô chạy bằng động cơ trên đường cao tốc (Tốc độ trung bình ~ 80 km/h).");
        }

        public double TinhChiPhi(double quangDuongKm)
        {
            // Giả định: 10 km tốn 1 lít xăng, giá xăng 20,000 VNĐ/lít
            return (quangDuongKm / 10.0) * 20000;
        }
    }

    // Lớp XeDap thực thi interface IMove
    public class XeDap : IMove
    {
        public void DiChuyen()
        {
            Console.WriteLine("Xe đạp di chuyển bằng sức người (Tốc độ trung bình ~ 15 km/h).");
        }

        public double TinhChiPhi(double quangDuongKm)
        {
            // Xe đạp không tốn nhiên liệu
            return 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Thiết lập tiếng Việt cho Console
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            Console.WriteLine("=== DEMO BÀI 7: QUẢN LÝ PHƯƠNG TIỆN (INTERFACE & ĐA HÌNH) ===");

            // Tạo danh sách đa hình chứa các loại phương tiện thông qua interface IMove
            List<IMove> dsPhuongTien = new List<IMove>
            {
                new XeMay(),
                new OTo(),
                new XeDap()
            };

            double quangDuongTest = 50.0; // Khoảng cách giả định 50 km
            Console.WriteLine($"Mô phỏng di chuyển với quãng đường: {quangDuongTest} km\n");

            foreach (var pt in dsPhuongTien)
            {
                Console.WriteLine($"- Loại phương tiện: {pt.GetType().Name}");
                pt.DiChuyen();
                Console.WriteLine($"  Chi phí vận hành: {pt.TinhChiPhi(quangDuongTest):N0} VNĐ\n");
            }

            Console.ReadKey();
        }
    }
}