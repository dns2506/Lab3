﻿using System;

namespace Lab3_bai1
{
    // Lớp cơ sở Nguoi
    public class Nguoi
    {
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }

        public Nguoi(string hoTen, DateTime ngaySinh)
        {
            HoTen = hoTen;
            NgaySinh = ngaySinh;
        }
    }

    // Lớp SinhVien kế thừa từ Nguoi
    public class SinhVien : Nguoi
    {
        public string MaSV { get; set; }
        public double DiemTB { get; set; }

        public SinhVien(string ma, string ten, DateTime ngaySinh, double diem)
            : base(ten, ngaySinh)
        {
            MaSV = ma;
            DiemTB = diem;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Bắt buộc phải có hàm Main này để chương trình chạy
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Khởi tạo thử một đối tượng SinhVien để kiểm tra
            SinhVien sv = new SinhVien("SV001", "Đỗ Ngọc Sơn", new DateTime(2006, 6, 25), 8.5);

            Console.WriteLine("Đã tạo thành công sinh viên:");
            Console.WriteLine($"Mã SV: {sv.MaSV}");
            Console.WriteLine($"Họ tên: {sv.HoTen}");
            Console.WriteLine($"Ngày sinh: {sv.NgaySinh.ToString("dd/MM/yyyy")}");
            Console.WriteLine($"Điểm TB: {sv.DiemTB}");

            Console.ReadKey();
        }
    }
}